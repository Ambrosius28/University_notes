function I = Quadratura(f,a,b,m,metodo)
    if metodo == 1
        I = IntegraPuntoMedio(f,a,b,m);
    elseif metodo == 2
        I = IntegraTrapezi(f,a,b,m);
    elseif metodo == 3
        I = IntegraCavalieriSimpson(f,a,b,m);
    elseif metodo == 4
        I = IntegraGaussLegendre(f,a,b);
    else 
        error("inserire un metodo di integrazione valido");
    end


