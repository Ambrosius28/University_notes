function integrale = IntegraTrapezi(f, a, b, m)
    x = linspace (a, b, m+1);
    h = (b-a)/m;
    if m >= 2
        integrale = (h/2)*(f(a)+2*sum(f(x(2:m)))+f(b));
    else
        integrale = (h/2)*(f(a)+f(b));
    end

