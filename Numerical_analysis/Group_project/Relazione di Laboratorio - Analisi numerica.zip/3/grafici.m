m = (1:100);

EMediof = [];
ETrapf = [];
EGLf = [];
ECSf = [];

Intf = 33/5;

for i = 1:100
    EMediof(i) = abs(Intf - Quadratura(@(x)(x.^(4)),-1,2,i,1));
    ETrapf(i) = abs(Intf - Quadratura(@(x)(x.^(4)),-1,2,i,2));
    EGLf(i) = abs(Intf - Quadratura(@(x)(x.^(4)),-1,2,i,3));
    ECSf(i) = abs(Intf - Quadratura(@(x)(x.^(4)),-1,2,i,4));
end

%creo il grafico per gli errori relativo alla prima funzione
figure
title("Errori in scala logaritmica per la prima funzione")
plot(EMediof, m);
hold on
plot(ETrapf,m);
plot(EGLf,m);
plot(ECSf,m);
legend(["metodo del punto medio", "metodo dei trapezi", "metodo di Gauss-Legendre", "metodo di Cavalieri Simpson"])
set(gca , 'XScale', 'log', 'YScale', 'log') ;
hold off