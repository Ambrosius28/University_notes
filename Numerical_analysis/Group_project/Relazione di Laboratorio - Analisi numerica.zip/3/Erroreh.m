function E = Erroreh(metodo,m)
    E = abs((exp(1)-1) - Quadratura(@(x)(exp(x)),0,1,m,metodo));
end
