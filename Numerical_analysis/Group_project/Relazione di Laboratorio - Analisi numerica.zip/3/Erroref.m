%definisco la funzione E che mi dà l'errore in funzione del metodo e di
%m, assumo di usare x^4
function E = Erroref(metodo,m)
    E = abs((33/5) - Quadratura(@(x)(x.^(4)),-1,2,m,metodo));
end




