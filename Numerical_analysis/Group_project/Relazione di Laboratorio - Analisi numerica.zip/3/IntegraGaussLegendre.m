function integrale = IntegraGaussLegendre(f,a,b)
    integrale = (b-a)*(0.5)*(f((b-a)*(2*sqrt(3))^(-1)+(a+b)/2)+f((b-a)*(-2*sqrt(3))^(-1)+(a+b)/2));
end
