%definisco le funzioni
f = @(x)(x.^(4));
g = @(x)(cos(x));
h = @(x)(exp(x));

%provo la funzione quadratura con la prima funzione
i = 1;
disp("Al variare del metodo di integrazione, l'integrale della prima funzione risulta:");
while i < 5
    disp(Quadratura(f,-1,2,100,i));
    i = i+1;
end
%provo la funzione quadratura con la seconda funzione
j = 1;
disp("Al variare del metodo di integrazione, l'integrale della seconda funzione risulta:");
while j < 5
    disp(Quadratura(g,-pi/2, pi/2, 100,j));
    j = j+1;
end
%provo la funzione quadratura con la terza funzione
k = 1;
disp("Al variare del metodo di integrazione, l'integrale della terza funzione risulta:");
while k < 5
    disp(Quadratura(h,0,1,100,k));
    k = k+1;
end

 



