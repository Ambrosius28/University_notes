%funzione che calcola gli errori per la seconda integranda in funzione del
%metodo e di m
function E = Erroreg(metodo,m)
    E = abs(2 - Quadratura(@(x)(cos(x)),-pi/2,pi/2,m,metodo));
end
