function integrale = IntegraPuntoMedio (f, a, b, m)
    x = linspace (a, b, 2*m+1);
    h = (b-a)/m;
    integrale = h*sum(f(x(2:2:2*m)));
    end
  
