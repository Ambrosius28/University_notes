function integrale = IntegraCavalieriSimpson (f, a, b, m)
    h = (b-a)/m;
    x = linspace(a, b, 2*m+1);
    if m >= 2
        integrale = (h/6)*(f(a)+2*sum(f(x(3:2:2*m-1)))+4*sum(f(x(2:2:2*m)))+f(b));
    else
        integrale = (h/6)*(f(a)+4*f((a+b)/2)+f(b));
    end

