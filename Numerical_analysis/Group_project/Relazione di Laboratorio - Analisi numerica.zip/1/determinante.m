function [d] = determinante(A)

[P, L, U, num] = lu_piv(A);


d= (-1)^num*prod(diag(U)); %uso della funzione prod presente in matlab
                           %per il prodotto degli elementi del vettore
end
