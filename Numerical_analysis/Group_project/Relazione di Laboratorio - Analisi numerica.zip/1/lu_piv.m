function [P, L, U, num] = lu_piv(A)
[n, m] = size(A);

if n~=m
    error('A non è una matrice quadrata')
end

U = A;      %inizializzo le matrici P,L,U
L = eye(n);
P = eye(n);
num = 0; %numero di scambi righe per il calcolo del det(P)

for k = 1:n-1
    [value, index] = max(abs(U(k:n,k))); %indice riga dell'elemento max 
    index = index + k -1;               %"value" a_ik della kima colonna
    if index ~= k
        num = num+1; %aggiorno il numero di scambi

        U([index, k], k:n) = U([k, index], k:n); %scambio per P,L,U la porzione 
        L([index, k], 1:k-1) = L([k, index], 1:k-1); %di riga interessata 
        P([index, k], :) = P([k, index], :);   %nel pivoting

    end


    for i = k+1:n    %per il resto eseguo lu_nopiv
        L(i, k) = U(i, k) / U(k, k);
        U(i, k:n) = U(i, k:n) - L(i, k) * U(k, k:n);
    end
end
end


