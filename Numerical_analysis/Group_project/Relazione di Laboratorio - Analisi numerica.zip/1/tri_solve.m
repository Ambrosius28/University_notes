function[x] = tri_solve(A, b)
[n, m] = size(A); %verifico che A sia nxn
x = zeros(n, 1); %inizializzo un vettore colonna n-dim

if n~= m
    warning('Solo matrici quadrate')
    return
end

if min(abs(diag(A))) == 0       %controllo che nessun elemento sulla 
    error('Sistema singolare')  %diagonale sia nullo
end

 if istriu(A) % Se la matrice A è triangolare superiore
        x(n) = b(n) / A(n, n);
        for j = n-1:-1:1  %diminuisce con passo -1 fino a 1
            x(j) = (b(j) - A(j, j+1:n) * x(j+1:n)) / A(j, j);
        end
    
elseif istril(A) % Se la matrice A è triangolare inferiore
    x(1) = b(1) / A(1, 1);
    for j = 2:n
        x(j) = (b(j) - A(j, 1:j-1) * x(1:j-1)) / A(j,j);
    end

else
    x = NaN;
    fprintf('Non ho un sistema triangolare')
end

end

