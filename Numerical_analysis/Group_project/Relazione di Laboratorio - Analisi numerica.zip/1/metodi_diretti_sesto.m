m = 50;
n = 12;

f = @(x) cos(4*x);
t = linspace(0, 1, m);
b = f(t)';
A = zeros(m, n);
for i = 1:n
    A(:,i) = (t.^(i-1))';
end

 C = zeros(n, 4);  %matrice con le 4 liste di coefficienti
%devo risolvere tAAx = tAb

%soluzione col comando \ di Matlab
c_1 = (A'*A) \ (A'*b);
C(:, 1) = c_1;

%soluzione tramite fatt. QR con sgs
[Q, R] = sgs(A);
y = Q' *b;
c_2 = tri_solve(R, y);
%x_2 = linsolve(R, Q' *b);
C(:, 2) = c_2;

%soluzione tramite fatt. QR con mgs
[Q, R] = mgs(A);
y = Q' *b;
c_3 = tri_solve(R, y);
%x_3 = linsolve(R, Q' *b);
C(:, 3) = c_3;

%soluzione qr
[Q, R] = qr(A);
y = Q' *b;
c_4 = linsolve(R, y);
C(:, 4) = c_4;

%matrice delle differenze
D = abs ( C(: , 1:3) - repmat ( C(: , 4) , 1 , 3) );
                        %crea una matrice 1x3 contenente la 4 colonna di C
                        % ripetuta nelle 3 colonne
            

format long
disp('Coefficienti')
disp(C)
disp("Matrice delle differenze tra i coefficienti dei vari metodi e quelli qr")
disp(D)

