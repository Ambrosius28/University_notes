function [L, U] = lu_nopiv(A)
[n, m] = size(A);

if n~=m
    error('A non è una matrice quadrata')
end

U = A;        %inizializzo U e L
L = eye(n);
for k = 1:n-1
    if A(k,k) == 0   %controllo che gli el. pivotali siano non nulli
        error('Elemento pivotale nullo')
    end
    for i = k+1:n   %nelle righe successive alla kesima, definisco l_ik
        L(i,k) = U(i,k) / U(k,k);    %e sottraggo alla iesima riga
        U(i, k:n) = U(i, k:n) - L(i,k)*U(k, k:n);  %l_ik*kesima riga
    end
end
end
