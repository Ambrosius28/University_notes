function [Q, R] = mgs(A)
[m,n] = size(A); %matrice mxn
R = zeros(n);  %inizializzo Q e R
Q = A;

for i = 1:n    %per ogni colonna i
    R(i,i) = norm(Q(:,i), 2);    %ne calcolo la norma euclidea
    Q(:, i) = Q(:, i) / R(i,i);  % e la normalizzo
    for j= i+1:n                 %considero le colonne j > i
        R(i,j) = Q(:,i)'*Q(:,j);   %prod scalare tra Q_i e Q_j
        Q(:,j) = Q(:, j) - R(i,j)*Q(:,i);  %aggiorno Q_j
    end 
end
end

