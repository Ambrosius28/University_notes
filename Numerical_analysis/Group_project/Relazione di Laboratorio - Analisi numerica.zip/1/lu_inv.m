function [X] = lu_inv(A)
[n,m] = size(A);

if n~=m
    error('A non è una matrice quadrata')
end

if det(A) == 0
    error('Matrice A singolare')
end

[P, L, U] = lu_piv(A);  %eseguo la fattorizzazione LU con pivoting
X = zeros(n);   %inizializzo l'inversa

for i = 1:n
    y = tri_solve(L, P(:,i));  %per tutti i vettori colonna risolvo il sist.
    X(:, i) = tri_solve(U, y); %triangolare Ly_i = Pe_i e Ux_i = y_i
end