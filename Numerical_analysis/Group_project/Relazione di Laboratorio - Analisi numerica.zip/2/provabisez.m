%testo la funzione bisezione che ho scritto
f = @(x)(exp(x)-(x.^2)-sin(x)-1);

fplot(f,[-2,2]); grid on
[c,fc,iter] = Bisezione(f,1,1.5,1e-12,100)  %non ho messo il ';' per far stampare a terminale i risultati


