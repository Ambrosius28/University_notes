function [alpha, fa, iter] = NewtonRaphson(f,df,x0,tol,itmax)
    delta = 1;
    for i = 0:itmax
        alpha = x0;
        fa = f(x0);
        iter = i;
        if abs(delta) <= tol | df(x0) == 0    %nota: il metodo potrebbe sbagliare se la funzione ha un punto stazionario diverso dalla radice in accordo con la teoria
            break
        else
            delta = -fa/(df(x0));
            x0 = x0+delta;
        end
    end
end



