f = @(x)((x-1)*(log(x)));
df = @(x)((x-1)/x + log(x));

%inizializzo le liste
ErrNR = [];
ErrNRmod = [];
xnorm = [];
xmod = [];
x = [];

%riempio le liste in funzione di itmax

for i = 1:100
    ErrNR(i) = abs(1-NewtonRaphson(f,df,5,1e-12,i));
    ErrNRmod(i) = abs(1-NewtonRaphsonMod(f,df,5,1e-12,i));
    xnorm(i) = abs(1-NewtonRaphson(f,df,5,1e-12,i-1));
    xmod(i) = abs(1-NewtonRaphsonMod(f,df,5,1e-12,i-1));
    x(i) = i;
end

%faccio i grafici
figure
tiledlayout(2,1)
loglog(nexttile,x,ErrNR,'-b');
hold on
loglog(x,xnorm,'-k')
title('errore logaritmico Newton Raphson')
hold off
legend({'errore', 'x'})

loglog(nexttile,x,ErrNRmod, '-r')
hold on 
loglog(x,xmod.^2, '-k')
title('errore logaritmico Newton Raphson Modificato')
hold off
legend({'errore', 'x^2'})





