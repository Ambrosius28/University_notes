function[c,fc,iter] = Bisezione(f,a,b,tol,itmax)
    c = a;
    fc = f(a);
    iter = 0;

    for i = 1:itmax
        if abs(fc) < tol
            break
        else
            c = (a+b)/2;
            fc = f(c);
            iter = i;
           
            if f(a)*f(c) < 0
                b = c;
            else
                a = c;
            end
        end
    end
   

        
