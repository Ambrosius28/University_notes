f = @(x)((x-1)*(log(x)));
df = @(x)((x-1)/x + log(x));

fplot(f,[0.5,5]); grid on
[c,fc,iter] = NewtonRaphsonMod(f,df,5,1e-12,10)