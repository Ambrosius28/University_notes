f = @(t,y)(sin(t)*(1+cos(t)-y));
y = @(t)(2 + cos(t));

a = 0;
b = 1;
y0 = 3;
tol = 10^(-6);
maxit = 100;
    
%faccio i grafici

figure
tiledlayout(2,1)

%Eulero Implicito 
e = [];
x = [];
for i = 1:100    
    N = i;
    h = (b-a)/N;
    x(i) = h;    
    t = linspace(a,b,N+1);
    u = y(t)-EuleroImplicito(a,b,y0,f,N,tol,maxit);
    e(i) = max(abs(u));
end

plot(nexttile, x, e, '-b');
hold on
plot(x,x,'-k');
plot(x,x.^2,'-r')
plot(x,x.^3,'-g');
title('Errore logaritmico metodo di Eulero implicito')
legend({'Errore', 'x', 'x^2', 'x^3'});
set(gca, 'XScale', 'log', 'YScale', 'log');
hold off

%Crank Nicolson
e = [];
x = [];
for i = 1:100
    N = i;
    h = (b-a)/N;
    x(i) = h;
    t = linspace(a,b,N+1);
    u = y(t) - CrankNicolson(a,b,y0,f,N,tol,maxit);
    e(i) = max(abs(u));
end


plot(nexttile,x,e,'-b');
hold on
plot(x,x,'-k');
plot(x,x.^2,'-r');
plot(x,x.^3,'-g');
title('Errore logaritmico metodo di Crank Nicolson')
legend({'Errore', 'x', 'x^2', 'x^3'});
set(gca, 'XScale', 'log','YScale', 'log');
hold off
