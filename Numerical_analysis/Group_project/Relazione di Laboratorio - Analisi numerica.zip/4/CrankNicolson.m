function u = CrankNicolson(a,b,y0,f,N,tol,maxit)
    h = (b-a)/N; %definisco il passo tra due nodi
    u = [y0]; %inizializzo la lista di valori
    %riempio la lista
    for j =  1:N
        g = @(x)(u(j)+h*(0.5)*(f(a+(j-1)*h,u(j))+f(a+j*h,x))); %funzione per applicare il metodo di punto fisso 
        %applico il metodo di punto fisso
        zk = u(j);
        for i = 1:maxit
            zk = g(zk);
            if abs((zk-g(zk))/g(zk)) < tol
                break
            end
        end
        u(j+1) = zk; %aggiungo alla lista il valore trovato
    end
end

