f = @(t,y)((-5)*y);
y = @(t)(exp((-5)*t));

a = 0;
b = 8;
y0 = 1;

N1 = 19;
N2 = 20;
N3 = 21;

figure
tiledlayout(3,1)
%per N1:
approx = EuleroEsplicito(a,b,y0,f,N1);
x = linspace(a,b,N1+1);
esatt = y(x);
    
plot(nexttile, x, esatt, '-b');
hold on
plot(x, approx, '-k');
title('grafico per N = 19');
legend({'soluzione esatta', 'soluzione approssimata'});

hold off

%per N2:
approx = EuleroEsplicito(a,b,y0,f,N2);
x = linspace(a,b,N2+1);
esatt = y(x);

plot(nexttile, x, esatt, '-b');
hold on
plot(x, approx, '-k');
title('grafico per N = 20');
legend({'soluzione esatta', 'soluzione approssimata'});

hold off

%per N3:
approx = EuleroEsplicito(a,b,y0,f,N3);
x = linspace(a,b,N3+1);
esatt = y(x);

plot(nexttile, x, esatt, '-b');
hold on
plot(x, approx, '-k');
title('grafico per N = 21');
legend({'soluzione esatta', 'soluzione approssimata'});

hold off




