function u = Heun(a, b, y0, f, N)
    u = [y0];
    h = (b-a)/N;
    for j = 1:N
        x = f(a+(j-1)*h, u(j));
        u(j+1) = u(j) + h*0.5*(x + f(a+j*h, u(j)+h*x));
    end
end