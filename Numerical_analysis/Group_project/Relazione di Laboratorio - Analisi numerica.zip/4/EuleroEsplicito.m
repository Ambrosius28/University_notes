function u = EuleroEsplicito(a, b, y0, f, N)
    u = [y0];
    h = (b-a)/N;
    for j = 1:N
        u(j+1) = u(j) + h*f(a+(j-1)*h, u(j));
    end
end