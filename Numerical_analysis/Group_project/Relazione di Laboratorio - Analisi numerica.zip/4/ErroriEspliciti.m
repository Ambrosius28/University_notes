f = @(t,y)(sin(t)*(1+cos(t)-y));
y = @(t)(2 + cos(t));

a = 0;
b = 1;
y0 = 3;

%faccio i grafici

figure
tiledlayout(2,1)

%eulero esplicito 
e = [];
x = [];
for i = 1:100     
    N = i;
    h = (b-a)/N;
    x(i) = h;     
    t = linspace(a,b,N+1);
    u = y(t)-EuleroEsplicito(a,b,y0,f,N);
    e(i) = max(abs(u));
end

plot(nexttile, x, e, '-b');
hold on
plot(x,x,'-k');
plot(x,x.^2,'-r')
plot(x,x.^3,'-g');
title('Errore logaritmico metodo di Eulero esplicito')
legend({'Errore', 'x', 'x^2', 'x^3'});
set(gca, 'XScale', 'log', 'YScale', 'log');
hold off

%Heun
e = [];
x = [];
for i = 1:100
    N = i;
    h = (b-a)/N;
    x(i) = h;
    t = linspace(a,b,N+1);
    u = y(t) - Heun(a,b,y0,f,N);
    e(i) = max(abs(u));
end

plot(nexttile,x,e,'-b');
hold on
plot(x,x,'-k');
plot(x,x.^2,'-r');
plot(x,x.^3,'-g');
title('Errore logaritmico metodo di Heun')
legend({'Errore', 'x', 'x^2', 'x^3'});
set(gca, 'XScale', 'log','YScale', 'log');
hold off


